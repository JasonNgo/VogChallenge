//
//  VogViewController.swift
//  VogAppChallenge
//
//  Created by Jason Ngo on 2019-03-29.
//  Copyright © 2019 Jason Ngo. All rights reserved.
//

import UIKit

class VogViewController: UIViewController {
    
    // MARK: - Views
    private lazy var saveUserInfoButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Save User Information", for: .normal)
        button.addTarget(self, action: #selector(handleSaveUserInfoTapped), for: .touchUpInside)
        return button
    }()
    
    private lazy var savePasswordInfoButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Save Password Information", for: .normal)
        button.addTarget(self, action: #selector(handleSavePasswordInfoTapped), for: .touchUpInside)
        return button
    }()
    
    private lazy var stackView: UIStackView = {
        let stackView = UIStackView.init(arrangedSubviews: [
            saveUserInfoButton,
            savePasswordInfoButton
        ])
        stackView.axis = .vertical
        stackView.spacing = 8
        stackView.distribution = .fillEqually
        return stackView
    }()
    
    // MARK: - View Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
        fetchProfileInformation()
    }
    
    // MARK: - Selectors
    @objc private func handleSaveUserInfoTapped() {
        APIService.shared.mockRequest(.updateProfileInformation(firstName: "Johnny B", lastName: "Goode")) { (result) in
            switch result {
            case .success(let data):
                guard let json = try? JSONSerialization.jsonObject(with: data, options: []) else {
                    print("Error parsing JSON")
                    return
                }
                print(json)
            case .failure(let error):
                print("Error! \(error)")
            }
        }
    }
    
    @objc private func handleSavePasswordInfoTapped() {
        APIService.shared.mockRequest(.updatePasswordInformation(currentPwd: "CURRENT_PWD", newPwd: "NEW_PWD", pwdConfirmation: true)) { (result) in
            switch result {
            case .success(let data):
                guard let json = try? JSONSerialization.jsonObject(with: data, options: []) else {
                    print("Error parsing JSON")
                    return
                }
                print(json)
            case .failure(let error):
                print("Error! \(error)")
            }
        }
    }
    
    // MARK: - Setup
    private func setupViews() {
        view.backgroundColor = .white
        
        view.addSubview(stackView)
        stackView.fillSuperview()
    }
    
    // MARK: - Helpers
    private func fetchProfileInformation() {
        APIService.shared.mockRequest(.fetchProfileInformation) { (result) in
            switch result {
            case .success(let data):
                guard let json = try? JSONSerialization.jsonObject(with: data, options: []) else {
                    print("Error parsing JSON")
                    return
                }
                print(json)
            case .failure(let error):
                print("Error! \(error)")
            }
        }
    }
    
}
